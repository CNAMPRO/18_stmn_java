package exercice3.model;

public enum BoxState {
	UNTRIGGERED,
	TRIGGERED
}