package exercice3.model;

public enum CellState {
	UNTRIGGERED,
	TRIGGERED
}