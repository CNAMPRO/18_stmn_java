package exercice1;
import java.util.Arrays;
import java.util.OptionalInt;

public class RasterBand {

	private int[][] values;
	
	public RasterBand(int[][] values) {
		this.values = values;
	}
	
	public int[][] getValues() {
		return values;
	}
	
	public int getWidth() {
		return values[0].length;
	}
	
	public int getHeight() {
		return values.length;
	}
	
	private int getMin() throws Exception {
		OptionalInt min = Arrays.stream(values).flatMapToInt(Arrays::stream).min();
		if (!min.isPresent()) {
			throw new Exception("Matrix is malformed");
		}
		return min.getAsInt();
	}
	
	private int getMax() throws Exception {
		OptionalInt max = Arrays.stream(values).flatMapToInt(Arrays::stream).max();
		if (!max.isPresent()) {
			throw new Exception("Matrix is malformed");
		}
		return max.getAsInt();
	}
	
	public void normalize() throws Exception {
		int min = getMin();
		int max = getMax();
		for (int i=0; i<values.length; ++i) {
			for (int j=0; j<values[i].length; ++j) {
				values[i][j] = (int)Normalizer.stretch(values[i][j], min, max, 0, 255);
			}
		}
	}

}
