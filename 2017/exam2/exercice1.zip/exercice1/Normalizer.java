package exercice1;


public class Normalizer {

	public static final double normalize(double x, double xmin, double xmax) throws Exception{
		int compare = Double.compare(xmin, xmax);
		if (compare>0) {
			throw new Exception(String.format("Invalid range [%f, %f]", xmin, xmax));
		}
		else if (compare==0) {
			return 0;
		}
		else {
			return (x-xmin)/(xmax-xmin);
		}
	}
	
	public static final double stretch(double x, double xmin, double xmax, double a, double b) throws Exception {
		int compare = Double.compare(xmin, xmax);
		if (compare>0) {
			throw new Exception(String.format("Invalid range [%f, %f]", xmin, xmax));
		}
		else if (compare==0) {
			return 0;
		}
		else {
			return (x-xmin)*(b-a)/(xmax-xmin)+a;
		}
		
	}
}
