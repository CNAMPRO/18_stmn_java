package exercice2.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.ArrayList;

import javax.swing.JFrame;

import exercice2.model.Cell;
import exercice2.model.CellGroup;
import exercice2.model.Grid;
import exercice2.model.Spec;
import exercice2.view.SpecWidget.Orientation;

public class GridWidget extends JFrame {
	
	public GridWidget(Grid model, Spec[] lineSpecs, Spec[] colSpecs) {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new GridBagLayout());
		
		GridBagConstraints c = new GridBagConstraints();
		CellWidget cw;
		SpecWidget l;
		
		ArrayList<CellGroup> groups = model.getLines();
		for (int i=0; i<lineSpecs.length; ++i) {
			c.gridx = 0;
			c.gridy = i+1;
			//c.fill = GridBagConstraints.HORIZONTAL;
			c.anchor = GridBagConstraints.EAST;
			l = new SpecWidget(lineSpecs[i], groups.get(i), Orientation.HORIZONTAL);
			add(l, c);
		}
		groups = model.getColumns();
		for (int j=0; j<colSpecs.length; ++j) {
			c.gridx = j+1;
			c.gridy = 0;
			//c.fill = GridBagConstraints.VERTICAL;
			c.anchor = GridBagConstraints.SOUTH;
			l = new SpecWidget(colSpecs[j],groups.get(j), Orientation.VERTICAL);
			add(l, c);
		}
		
		int currentRow = 1;
		int currentColumn = 1;
		for (CellGroup group:model.getLines()) {
			for (Cell cell:group.getCells()) {
				cw = new CellWidget(cell);
				c.gridx = currentColumn;
				c.gridy = currentRow;		
				add(cw, c);
				++currentColumn;
			}
			++currentRow;
			currentColumn = 1;
		}
	}

}
