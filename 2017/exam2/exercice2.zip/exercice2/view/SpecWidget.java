package exercice2.view;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import exercice2.model.CellGroup;
import exercice2.model.Spec;

public class SpecWidget extends JPanel /*implements ? */{
	
	public enum Orientation {HORIZONTAL, VERTICAL};
	
	private final Spec model;
	private final CellGroup cellGroup;
	private final JLabel[] labels;
	
	public SpecWidget(Spec model, CellGroup cellGroup, Orientation o) {
		this.model = model;
		this.cellGroup = cellGroup;
		this.cellGroup.addObserver(this.model);
		
		this.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		labels = new JLabel[model.specs.length];
		
		for (int i=0; i<labels.length; ++i) {
			labels[i] = new JLabel(String.valueOf(this.model.specs[i]));
			if (o==Orientation.HORIZONTAL) {
				c.gridx = i;
				c.gridy = 0;
				c.weightx = 1.0;
				c.anchor = GridBagConstraints.EAST;
				labels[i].setPreferredSize(new Dimension(labels[i].getPreferredSize().height, labels[i].getPreferredSize().height));
			}
			else {
				c.gridx = 0;
				c.gridy = i;
				c.weighty = 1.0;
				c.anchor = GridBagConstraints.SOUTH;
			}
			this.add(labels[i],c);
		}
	}

}
