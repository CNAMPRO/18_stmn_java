package exercice2.view;

import java.awt.Color;

public class Constants {

	public static final Color UNCHECKED = new Color(98, 146, 158);
	public static final Color CHECKED = new Color(74, 109, 124);

}
