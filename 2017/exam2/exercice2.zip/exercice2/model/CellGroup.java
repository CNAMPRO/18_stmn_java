package exercice2.model;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

public class CellGroup extends Observable implements Observer {

	private ArrayList<Cell> cells = new ArrayList<>();
	//private CellState state;
	
	public CellGroup() {
	}

	public void addCells(Cell cell) {
		cell.addObserver(this);
		cells.add(cell);
		update(null, cell.getState());
	}
	
//	public void setState(CellState state) {
//		this.state = state;
//		setChanged();
//		notifyObservers(state);
//	}
//	public CellState getState() {
//		return state;
//	}
	
	public int getFilledCount() {
		int count = 0;
		for (Cell cell:cells) {
			if (cell.getState() == CellState.CHECKED) {
				++count;
			}
		}
		return count;
	}
	
	@Override
	public void update(Observable o, Object state) {
		if (cells.isEmpty()) return;
		setChanged();
		notifyObservers(getFilledCount());
	}
	
	public ArrayList<Cell> getCells() {
		return cells;
	}

}
