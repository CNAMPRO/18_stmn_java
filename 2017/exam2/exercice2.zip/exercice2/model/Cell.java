package exercice2.model;

import java.util.Observable;

public class Cell extends Observable {
	private CellState state = CellState.UNCHECKED;
	
	public CellState getState() {
		return state;
	}
	
	public void setState(CellState state) {
		this.state = state;
		setChanged();
		notifyObservers(state);
	}
	
	public void toggleCheck() {
		switch (state) {
		case UNCHECKED:
			setState(CellState.CHECKED);
			break;
		case CHECKED:
			setState(CellState.UNCHECKED);
			break;
		default:
			return;
		}
	}
}
