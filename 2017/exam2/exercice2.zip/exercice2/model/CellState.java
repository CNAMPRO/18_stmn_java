package exercice2.model;

public enum CellState {
	UNCHECKED,
	CHECKED
}