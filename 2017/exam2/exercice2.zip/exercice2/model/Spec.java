package exercice2.model;

import java.util.Observable;
import java.util.Observer;
import java.util.stream.IntStream;

public class Spec extends Observable implements Observer {

	public final int[] specs;
	protected boolean isValid;
	
	public Spec(int[] specs) {
		this.specs = specs;
		this.isValid = false;
	}

	public void setValid(boolean valid) {
		isValid = valid;
		setChanged();
		notifyObservers(isValid);
	}
	
	public boolean isValid() {
		return isValid;
	}
	
	@Override
	public void update(Observable arg0, Object arg1) {
		int count = IntStream.of(specs).sum();
		setValid(count == (int)arg1);
	}

}
