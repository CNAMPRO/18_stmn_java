package exercice2;

import exercice2.model.Grid;
import exercice2.model.Spec;
import exercice2.view.GridWidget;

public class Launcher {
	public static void main(String[] args) {
		Grid model = new Grid(3, 4);
		Spec[] lineSpecs = new Spec[3];
		lineSpecs[0] = new Spec(new int[] {3});
		lineSpecs[1] = new Spec(new int[] {1,1});
		lineSpecs[2] = new Spec(new int[] {2});
		Spec[] colSpecs = new Spec[4];
		colSpecs[0] = new Spec(new int[] {1});
		colSpecs[1] = new Spec(new int[] {2});
		colSpecs[2] = new Spec(new int[] {1,1});
		colSpecs[3] = new Spec(new int[] {2});
		GridWidget main = new GridWidget(model, lineSpecs, colSpecs);
		
		main.pack();
		main.setVisible(true);
	}
}
