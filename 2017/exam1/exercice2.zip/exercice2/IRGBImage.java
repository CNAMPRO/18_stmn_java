package exercice2;

public interface IRGBImage {
	int[][] getRedBand();
	int[][] getGreenBand();
	int[][] getBlueBand();
	
	int width();
	int height();
}
