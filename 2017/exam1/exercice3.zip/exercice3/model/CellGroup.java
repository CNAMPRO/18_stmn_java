package exercice3.model;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

public class CellGroup extends Observable implements Observer {

	private ArrayList<Cell> cells = new ArrayList<>();
	private CellState state;
	
	public CellGroup() {
	}

	public void addCells(Cell cell) {
		cell.addObserver(this);
		cells.add(cell);
		update(null, cell.getState());
	}
	
	public void setState(CellState state) {
		this.state = state;
		setChanged();
		notifyObservers(state);
	}
	public CellState getState() {
		return state;
	}
	
	
	@Override
	public void update(Observable o, Object state) {
		if (cells.isEmpty()) return;
		for (Cell cell:cells) {
			if (cell.getState() != state) {
				setState(null);
				return;
			}
		}
		setState((CellState)state);
	}
	
	public ArrayList<Cell> getCells() {
		return cells;
	}

}
