package exercice3.model;

import java.util.ArrayList;

public class Grid {

	private ArrayList<CellGroup> lines = new ArrayList<>();
	private ArrayList<CellGroup> columns = new ArrayList<>();
	public final int nbRows;
	public final int nbColumns;
	
	public Grid(int nbRows, int nbColumns) {
		this.nbRows = nbRows;
		this.nbColumns = nbColumns;
		for (int i=0; i<nbRows; ++i) {
			lines.add(new CellGroup());
		}
		for (int j=0; j<nbColumns; ++j) {
			columns.add(new CellGroup());
		}
		
		Cell[][] cells = new Cell[nbRows][nbColumns];
		for (int i=0; i<nbRows; ++i) {
			for (int j=0; j<nbColumns; ++j) {
				cells[i][j] = new Cell();
				lines.get(i).addCells(cells[i][j]);
				columns.get(j).addCells(cells[i][j]);
			}
		}
	}
	
	public ArrayList<CellGroup> getLines() {
		return lines;
	}
	
	public ArrayList<CellGroup> getColumns() {
		return columns;
	}

}
