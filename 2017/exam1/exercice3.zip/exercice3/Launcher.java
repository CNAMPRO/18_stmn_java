package exercice3;

import exercice3.model.Grid;
import exercice3.view.GridWidget;

public class Launcher {
	public static void main(String[] args) {
		Grid model = new Grid(3, 4);
		GridWidget main = new GridWidget(model);
		
		main.pack();
		main.setVisible(true);
	}
}
