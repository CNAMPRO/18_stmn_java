package exercice3.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JFrame;

import exercice3.model.Cell;
import exercice3.model.CellGroup;
import exercice3.model.Grid;

public class GridWidget extends JFrame {
	
	public GridWidget(Grid model) {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new GridBagLayout());
		
		GridBagConstraints c = new GridBagConstraints();
		CellWidget cw;
		
		for (CellGroup group:model.getLines()) {
			// TODO: Add Led indicator for each line
		}
		for (CellGroup group:model.getColumns()) {
			//TODO: Add Led indicator for each column
		}
		
		int currentRow = 1;
		int currentColumn = 1;
		for (CellGroup group:model.getLines()) {
			for (Cell cell:group.getCells()) {
				cw = new CellWidget(cell);
				c.gridx = currentColumn;
				c.gridy = currentRow;		
				add(cw, c);
				++currentColumn;
			}
			++currentRow;
			currentColumn = 1;
		}
	}

}
