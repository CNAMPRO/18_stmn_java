package exercice3.view;

import java.awt.Dimension;

import javax.swing.JButton;

import exercice3.model.CellGroup;
import exercice3.model.CellState;
import exercice3.view.LedWidget.Orientation;

public class LedWidget extends JButton {

	private static final Dimension PREFERED_H_SIZE = new Dimension(10,  5);
	private static final Dimension PREFERED_V_SIZE = new Dimension(5,  10);
	
	public enum Orientation {HORIZONTAL, VERTICAL};
	
	private final CellGroup model;
	
	public LedWidget(CellGroup model, Orientation o) {
		this.model = model;
		
		switch (o) {
		case HORIZONTAL:
			setMinimumSize(PREFERED_H_SIZE);
			setPreferredSize(PREFERED_H_SIZE);
			break;
		case VERTICAL:
			setMinimumSize(PREFERED_V_SIZE);
			setPreferredSize(PREFERED_V_SIZE);
			break;
		}
		
		stateChanged(this.model.getState());
	}

	private void stateChanged(CellState state) {
		if (state==null) {
			setBackground(null);
			return;
		}
		switch (state) {
		case UNCHECKED:
			setBackground(Constants.UNCHECKED);
			break;
		case CHECKED:
			setBackground(Constants.CHECKED);
			break;
		default:
			return;	
		}
	}

}
