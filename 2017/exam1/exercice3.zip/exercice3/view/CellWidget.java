package exercice3.view;

import java.awt.Dimension;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;

import exercice3.model.Cell;
import exercice3.model.CellState;

public class CellWidget extends JButton implements Observer {

	private static final Dimension PREFERED_SIZE = new Dimension(25,  25);
	
	private final Cell model;
	
	public CellWidget(Cell model) {
		this.model = model;
		this.model.addObserver(this);
		
		setMinimumSize(PREFERED_SIZE);
		setPreferredSize(PREFERED_SIZE);
		
		addActionListener((e)->model.toggleState());
		
		stateChanged(this.model.getState());
	}

	private void stateChanged(CellState state) {
		switch (state) {
		case UNCHECKED:
			setBackground(Constants.UNCHECKED);
			setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			break;
		case CHECKED:
			setBackground(Constants.CHECKED);
			setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
			break;
		default:
			return;	
		}
	}
	
	@Override
	public void update(Observable arg0, Object state) {
		stateChanged((CellState)state);
	}

}
